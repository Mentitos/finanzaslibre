import 'package:flutter/material.dart';
import '../models/savings_record.dart';
import '../services/savings_data_manager.dart';
import '../widgets/stat_card.dart';
import '../widgets/record_dialog.dart';
import '../widgets/record_item.dart';
import '../widgets/quick_money_dialog.dart';
import '../utils/formatters.dart';
import '../constants/app_constants.dart';

class SavingsScreen extends StatefulWidget {
  const SavingsScreen({super.key});

  @override
  State<SavingsScreen> createState() => _SavingsScreenState();
}

class _SavingsScreenState extends State<SavingsScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final SavingsDataManager _dataManager = SavingsDataManager();
  final TextEditingController _searchController = TextEditingController();

  List<SavingsRecord> _allRecords = [];
  List<SavingsRecord> _filteredRecords = [];
  List<String> _categories = [];
  Map<String, dynamic> _statistics = {};

  String _currentFilter = 'all';
  String _selectedCategory = 'all';
  String _searchQuery = '';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      final records = await _dataManager.loadRecords();
      final categories = await _dataManager.loadCategories();
      final stats = await _dataManager.getStatistics();

      setState(() {
        _allRecords = records;
        _categories = categories;
        _statistics = stats;
        _applyFilters();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorSnackBar('Error al cargar los datos');
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredRecords = _allRecords.where((record) {
        bool matchesType = switch (_currentFilter) {
          'deposits' => record.type == RecordType.deposit,
          'withdrawals' => record.type == RecordType.withdrawal,
          _ => true,
        };

        bool matchesCategory = _selectedCategory == 'all' ||
            record.category == _selectedCategory;

        bool matchesSearch = _searchQuery.isEmpty ||
            record.description.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            record.category.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            (record.notes?.toLowerCase().contains(_searchQuery.toLowerCase()) ?? false);

        return matchesType && matchesCategory && matchesSearch;
      }).toList();
    });
  }

  Future<void> _addRecord(SavingsRecord record) async {
    try {
      final success = await _dataManager.addRecord(record);
      if (success) {
        await _loadData();
        _showSuccessSnackBar(AppConstants.recordSavedSuccess);
      } else {
        _showErrorSnackBar(AppConstants.saveError);
      }
    } catch (e) {
      _showErrorSnackBar(AppConstants.genericError);
    }
  }

  Future<void> _updateRecord(SavingsRecord record) async {
    try {
      final success = await _dataManager.updateRecord(record);
      if (success) {
        await _loadData();
        _showSuccessSnackBar(AppConstants.recordUpdatedSuccess);
      } else {
        _showErrorSnackBar(AppConstants.saveError);
      }
    } catch (e) {
      _showErrorSnackBar(AppConstants.genericError);
    }
  }

  Future<void> _deleteRecord(String id) async {
    try {
      final success = await _dataManager.deleteRecord(id);
      if (success) {
        await _loadData();
        _showSuccessSnackBar(AppConstants.recordDeletedSuccess);
      } else {
        _showErrorSnackBar('Error al eliminar el registro');
      }
    } catch (e) {
      _showErrorSnackBar(AppConstants.genericError);
    }
  }

  Future<void> _addCategory(String category) async {
    try {
      final success = await _dataManager.addCategory(category);
      if (success) {
        await _loadData();
        _showSuccessSnackBar(AppConstants.categorySavedSuccess);
      } else {
        _showErrorSnackBar(AppConstants.categoryExistsError);
      }
    } catch (e) {
      _showErrorSnackBar(AppConstants.genericError);
    }
  }

  Future<void> _deleteCategory(String category) async {
    try {
      final success = await _dataManager.deleteCategory(category);
      if (success) {
        await _loadData();
        _showSuccessSnackBar(AppConstants.categoryDeletedSuccess);
      } else {
        _showErrorSnackBar(AppConstants.categoryInUseError);
      }
    } catch (e) {
      _showErrorSnackBar(AppConstants.genericError);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: AppConstants.summaryTabTitle, icon: Icon(Icons.dashboard)),
            Tab(text: AppConstants.historyTabTitle, icon: Icon(Icons.history)),
            Tab(text: AppConstants.categoriesTabTitle, icon: Icon(Icons.category)),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _buildSummaryTab(),
                _buildHistoryTab(),
                _buildCategoriesTab(),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddRecordDialog,
        icon: const Icon(Icons.add),
        label: const Text('Nuevo'),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildSummaryTab() {
    return RefreshIndicator(
      onRefresh: _loadData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTotalCard(),
            const SizedBox(height: AppConstants.defaultPadding),
            _buildMoneyTypesRow(),
            const SizedBox(height: AppConstants.defaultPadding),
            _buildStatsRow(),
            const SizedBox(height: AppConstants.largePadding),
            if (_allRecords.isNotEmpty) _buildRecentMovements(),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalCard() {
    final totalAmount = _statistics['totalAmount']?.toDouble() ?? 0.0;
    final isPositive = totalAmount >= 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppConstants.largePadding),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isPositive
              ? [Colors.green.shade400, Colors.green.shade600]
              : [Colors.red.shade400, Colors.red.shade600],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppConstants.largeBorderRadius),
        boxShadow: [
          BoxShadow(
            color: (isPositive ? Colors.green : Colors.red).withOpacity(0.3),
            spreadRadius: 1,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            AppConstants.totalSavingsLabel,
            style: TextStyle(
              color: Colors.white,
              fontSize: AppConstants.largeFontSize,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${AppConstants.currencySymbol}${Formatters.formatCurrency(totalAmount)}',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.bold,
            ),
          ),
          if (_allRecords.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'Último movimiento: ${Formatters.formatRelativeDate(_allRecords.first.createdAt)}',
              style: const TextStyle(
                color: Colors.white70,
                fontSize: AppConstants.defaultFontSize,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMoneyTypesRow() {
    final physicalAmount = _statistics['totalPhysical']?.toDouble() ?? 0.0;
    final digitalAmount = _statistics['totalDigital']?.toDouble() ?? 0.0;

    return Row(
      children: [
        Expanded(
          child: MoneyStatCard(
            title: AppConstants.physicalMoneyLabel,
            amount: physicalAmount,
            icon: Icons.account_balance_wallet,
            color: AppConstants.physicalMoneyColor,
            onTap: () => _showQuickMoneyDialog(MoneyType.physical, physicalAmount),
          ),
        ),
        const SizedBox(width: AppConstants.defaultPadding),
        Expanded(
          child: MoneyStatCard(
            title: AppConstants.digitalMoneyLabel,
            amount: digitalAmount,
            icon: Icons.credit_card,
            color: AppConstants.digitalMoneyColor,
            onTap: () => _showQuickMoneyDialog(MoneyType.digital, digitalAmount),
          ),
        ),
      ],
    );
  }

  Widget _buildStatsRow() {
    final totalRecords = _statistics['totalRecords'] ?? 0;
    final totalDeposits = _statistics['totalDeposits'] ?? 0;
    final totalWithdrawals = _statistics['totalWithdrawals'] ?? 0;

    return Row(
      children: [
        Expanded(
          child: StatCard(
            title: 'Total Registros',
            value: '$totalRecords',
            icon: Icons.receipt_long,
            color: Colors.orange,
          ),
        ),
        const SizedBox(width: AppConstants.smallPadding),
        Expanded(
          child: StatCard(
            title: AppConstants.depositLabel,
            value: '$totalDeposits',
            icon: Icons.arrow_upward,
            color: AppConstants.depositColor,
          ),
        ),
        const SizedBox(width: AppConstants.smallPadding),
        Expanded(
          child: StatCard(
            title: AppConstants.withdrawalLabel,
            value: '$totalWithdrawals',
            icon: Icons.arrow_downward,
            color: AppConstants.withdrawalColor,
          ),
        ),
      ],
    );
  }

  Widget _buildRecentMovements() {
    final recentRecords = _allRecords.take(AppConstants.recentRecordsCount).toList();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Últimos Movimientos',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                TextButton(
                  onPressed: () => _tabController.animateTo(1),
                  child: const Text('Ver todos'),
                ),
              ],
            ),
            const SizedBox(height: AppConstants.defaultPadding),
            ...recentRecords.map((record) => RecentRecordItem(
              record: record,
              onTap: () => _showEditRecordDialog(record),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryTab() {
    return Column(
      children: [
        _buildSearchBar(),
        _buildFilters(),
        Expanded(
          child: _filteredRecords.isEmpty
              ? _buildEmptyState()
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppConstants.defaultPadding,
                    ),
                    itemCount: _filteredRecords.length,
                    itemBuilder: (context, index) {
                      final record = _filteredRecords[index];
                      return RecordItem(
                        record: record,
                        onEdit: () => _showEditRecordDialog(record),
                        onDelete: () => _showDeleteConfirmation(record),
                        showCategory: true,
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          hintText: 'Buscar registros...',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: _searchController.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    setState(() {
                      _searchQuery = '';
                      _applyFilters();
                    });
                  },
                )
              : null,
          border: const OutlineInputBorder(),
        ),
        onChanged: (value) {
          setState(() {
            _searchQuery = value;
            _applyFilters();
          });
        },
      ),
    );
  }

  Widget _buildFilters() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: AppConstants.defaultPadding),
      child: Row(
        children: [
          _buildFilterChip(AppConstants.allFilter, 'all'),
          const SizedBox(width: AppConstants.smallPadding),
          _buildFilterChip(AppConstants.depositsFilter, 'deposits'),
          const SizedBox(width: AppConstants.smallPadding),
          _buildFilterChip(AppConstants.withdrawalsFilter, 'withdrawals'),
          const SizedBox(width: AppConstants.defaultPadding),
          _buildCategoryDropdown(),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String text, String value) {
    final isSelected = _currentFilter == value;
    return FilterChip(
      label: Text(text),
      selected: isSelected,
      onSelected: (selected) {
        setState(() {
          _currentFilter = value;
          _applyFilters();
        });
      },
    );
  }

  Widget _buildCategoryDropdown() {
    return DropdownButton<String>(
      value: _selectedCategory,
      hint: const Text('Categoría'),
      items: [
        const DropdownMenuItem(
          value: 'all',
          child: Text('Todas las categorías'),
        ),
        ..._categories.map((category) => DropdownMenuItem(
              value: category,
              child: Text(category),
            )),
      ],
      onChanged: (value) {
        setState(() {
          _selectedCategory = value ?? 'all';
          _applyFilters();
        });
      },
    );
  }

  Widget _buildCategoriesTab() {
    final categoryTotals = _statistics['categoryTotals'] as Map<String, double>? ?? {};
    final categoryTotalsList = categoryTotals.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      child: Column(
        children: [
          _buildCategoryTotalsCard(categoryTotalsList),
          const SizedBox(height: AppConstants.defaultPadding),
          _buildCategoryManagementCard(),
        ],
      ),
    );
  }

  Widget _buildCategoryTotalsCard(List<MapEntry<String, double>> categoryTotals) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ahorros por Categoría',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: AppConstants.defaultPadding),
            if (categoryTotals.isEmpty)
              const Text('No hay datos disponibles')
            else
              ...categoryTotals.map((entry) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: AppConstants.getCategoryColor(entry.key),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: Text(entry.key)),
                        Text(
                          '${AppConstants.currencySymbol}${Formatters.formatCurrency(entry.value)}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: entry.value >= 0 ? Colors.green : Colors.red,
                          ),
                        ),
                      ],
                    ),
                  )),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryManagementCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.defaultPadding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Administrar Categorías',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                IconButton(
                  onPressed: _showAddCategoryDialog,
                  icon: const Icon(Icons.add),
                ),
              ],
            ),
            const SizedBox(height: AppConstants.defaultPadding),
            Wrap(
              spacing: 8,
              children: _categories.map((category) => Chip(
                label: Text(category),
                avatar: CircleAvatar(
                  backgroundColor: AppConstants.getCategoryColor(category),
                  radius: 8,
                ),
                deleteIcon: const Icon(Icons.close, size: 16),
                onDeleted: category != 'General'
                    ? () => _showDeleteCategoryConfirmation(category)
                    : null,
              )).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    String title = AppConstants.emptyRecordsTitle;
    String subtitle = AppConstants.emptyRecordsSubtitle;

    if (_searchQuery.isNotEmpty) {
      title = AppConstants.emptySearchTitle;
      subtitle = AppConstants.emptySearchSubtitle;
    } else if (_selectedCategory != 'all') {
      title = AppConstants.emptyCategoryTitle;
      subtitle = AppConstants.emptyCategorySubtitle;
    }

    return EmptyRecordsWidget(
      title: title,
      subtitle: subtitle,
      onActionPressed: _searchQuery.isEmpty ? _showAddRecordDialog : null,
      actionText: _searchQuery.isEmpty ? 'Agregar Registro' : null,
    );
  }

  // Diálogos y acciones
  void _showAddRecordDialog() {
    showDialog(
      context: context,
      builder: (context) => RecordDialog(
        onSave: _addRecord,
        categories: _categories,
        initialCategory: _selectedCategory != 'all' ? _selectedCategory : null,
      ),
    );
  }

  void _showEditRecordDialog(SavingsRecord record) {
    showDialog(
      context: context,
      builder: (context) => RecordDialog(
        onSave: _updateRecord,
        categories: _categories,
        record: record,
      ),
    );
  }

  void _showDeleteConfirmation(SavingsRecord record) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppConstants.deleteRecordTitle),
        content: Text(
          '¿Eliminar "${record.description.isEmpty ? record.category : record.description}"?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppConstants.cancelButtonLabel),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteRecord(record.id);
            },
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text(AppConstants.deleteButtonLabel),
          ),
        ],
      ),
    );
  }

  void _showAddCategoryDialog() {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Nueva Categoría'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Nombre de la categoría',
            border: OutlineInputBorder(),
          ),
          textCapitalization: TextCapitalization.words,
          maxLength: AppConstants.maxCategoryNameLength,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppConstants.cancelButtonLabel),
          ),
          FilledButton(
            onPressed: () {
              final name = controller.text.trim();
              if (AppConstants.isValidCategoryName(name) && 
                  !_categories.contains(name)) {
                Navigator.pop(context);
                _addCategory(name);
              } else if (_categories.contains(name)) {
                _showErrorSnackBar(AppConstants.categoryExistsError);
              } else {
                _showErrorSnackBar('Nombre de categoría inválido');
              }
            },
            child: const Text(AppConstants.addButtonLabel),
          ),
        ],
      ),
    );
  }

  void _showDeleteCategoryConfirmation(String category) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text(AppConstants.deleteCategoryTitle),
        content: Text('¿Eliminar la categoría "$category"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppConstants.cancelButtonLabel),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteCategory(category);
            },
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text(AppConstants.deleteButtonLabel),
          ),
        ],
      ),
    );
  }

  void _showQuickMoneyDialog(MoneyType moneyType, double currentAmount) {
    showDialog(
      context: context,
      builder: (context) => QuickMoneyDialog(
        moneyType: moneyType,
        onSave: _addRecord,
        categories: _categories,
        currentAmount: currentAmount,
      ),
    );
  }

  // Métodos de utilidad
  void _showSuccessSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppConstants.successColor,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppConstants.errorColor,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }
}