import 'package:flutter/material.dart';
import '../models/savings_record.dart';
import '../utils/formatters.dart';

class RecordItem extends StatelessWidget {
  final SavingsRecord record;
  final VoidCallback? onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final bool showCategory;
  final bool isCompact;

  const RecordItem({
    super.key,
    required this.record,
    this.onTap,
    this.onEdit,
    this.onDelete,
    this.showCategory = true,
    this.isCompact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 1,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(isCompact ? 12 : 16),
          child: isCompact ? _buildCompactContent() : _buildFullContent(),
        ),
      ),
    );
  }

  Widget _buildFullContent() {
    return Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildLeadingIcon(),
            const SizedBox(width: 16),
            Expanded(
              child: _buildMainContent(),
            ),
            _buildAmountDisplay(),
          ],
        ),
        if (onEdit != null || onDelete != null) ...[
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (onEdit != null)
                IconButton(
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit, size: 18),
                  tooltip: 'Editar',
                ),
              if (onDelete != null)
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete, size: 18, color: Colors.red),
                  tooltip: 'Eliminar',
                ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildCompactContent() {
    return Row(
      children: [
        _buildLeadingIcon(),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                record.description.isEmpty 
                    ? record.category 
                    : record.description,
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                Formatters.formatRelativeDate(record.createdAt),
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            _buildAmountDisplay(fontSize: 14),
            if (onEdit != null || onDelete != null)
              _buildPopupMenu(),
          ],
        ),
      ],
    );
  }

  Widget _buildLeadingIcon() {
    final color = record.type == RecordType.deposit ? Colors.green : Colors.red;
    final icon = record.type == RecordType.deposit ? Icons.add : Icons.remove;
    
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(
        icon,
        color: color,
        size: 20,
      ),
    );
  }

  Widget _buildMainContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Título principal
        Text(
          record.description.isEmpty ? 'Sin descripción' : record.description,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        
        const SizedBox(height: 4),
        
        // Información secundaria
        _buildSecondaryInfo(),
        
        const SizedBox(height: 8),
        
        // Desglose de montos
        _buildAmountBreakdown(),
        
        // Notas si existen
        if (record.notes?.isNotEmpty == true) ...[
          const SizedBox(height: 8),
          _buildNotesSection(),
        ],
      ],
    );
  }

  Widget _buildSecondaryInfo() {
    return Wrap(
      spacing: 8,
      runSpacing: 4,
      children: [
        if (showCategory) 
          _buildInfoChip(
            record.category,
            Icons.category,
            _getCategoryColor(record.category),
          ),
        _buildInfoChip(
          Formatters.formatRelativeDate(record.createdAt),
          Icons.access_time,
          Colors.grey,
        ),
      ],
    );
  }

  Widget _buildInfoChip(String text, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAmountBreakdown() {
    final List<Widget> amounts = [];
    
    if (record.physicalAmount > 0) {
      amounts.add(_buildAmountDetail(
        'Físico',
        record.physicalAmount,
        Icons.account_balance_wallet,
        Colors.blue,
      ));
    }
    
    if (record.digitalAmount > 0) {
      amounts.add(_buildAmountDetail(
        'Digital',
        record.digitalAmount,
        Icons.credit_card,
        Colors.purple,
      ));
    }
    
    return Wrap(
      spacing: 12,
      runSpacing: 4,
      children: amounts,
    );
  }

  Widget _buildAmountDetail(String label, double amount, IconData icon, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Text(
          '$label: \$${Formatters.formatCurrency(amount)}',
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }

  Widget _buildNotesSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.note,
            size: 16,
            color: Colors.grey[600],
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              record.notes!,
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 13,
                fontStyle: FontStyle.italic,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAmountDisplay({double fontSize = 16}) {
    final color = record.type == RecordType.deposit ? Colors.green : Colors.red;
    final prefix = record.type == RecordType.deposit ? '+' : '-';
    
    return Text(
      '$prefix\$${Formatters.formatCurrency(record.totalAmount)}',
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize,
        color: color,
      ),
    );
  }

  Widget _buildPopupMenu() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        switch (value) {
          case 'edit':
            onEdit?.call();
            break;
          case 'delete':
            onDelete?.call();
            break;
        }
      },
      itemBuilder: (context) => [
        if (onEdit != null)
          const PopupMenuItem(
            value: 'edit',
            child: Row(
              children: [
                Icon(Icons.edit, size: 18),
                SizedBox(width: 8),
                Text('Editar'),
              ],
            ),
          ),
        if (onDelete != null)
          const PopupMenuItem(
            value: 'delete',
            child: Row(
              children: [
                Icon(Icons.delete, size: 18, color: Colors.red),
                SizedBox(width: 8),
                Text('Eliminar'),
              ],
            ),
          ),
      ],
      child: Container(
        padding: const EdgeInsets.all(4),
        child: Icon(
          Icons.more_vert,
          size: 16,
          color: Colors.grey[600],
        ),
      ),
    );
  }

  Color _getCategoryColor(String category) {
    const colors = [
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.red,
      Colors.teal,
      Colors.indigo,
      Colors.pink,
      Colors.amber,
      Colors.cyan,
    ];
    
    final hash = category.hashCode;
    return colors[hash.abs() % colors.length];
  }
}

// Widget especializado para mostrar registros recientes de forma compacta
class RecentRecordItem extends StatelessWidget {
  final SavingsRecord record;
  final VoidCallback? onTap;

  const RecentRecordItem({
    super.key,
    required this.record,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Colors.grey[200]!,
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Row(
          children: [
            // Icono del tipo
            Icon(
              record.type == RecordType.deposit 
                  ? Icons.arrow_upward 
                  : Icons.arrow_downward,
              color: record.type == RecordType.deposit 
                  ? Colors.green 
                  : Colors.red,
              size: 20,
            ),
            
            const SizedBox(width: 12),
            
            // Información principal
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    record.description.isEmpty 
                        ? record.category 
                        : record.description,
                    style: const TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${record.category} • ${Formatters.formatRelativeDate(record.createdAt)}',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            
            const SizedBox(width: 8),
            
            // Monto
            Text(
              '${record.type == RecordType.deposit ? '+' : '-'}\$${Formatters.formatCurrency(record.totalAmount)}',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: record.type == RecordType.deposit 
                    ? Colors.green 
                    : Colors.red,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget para mostrar el estado vacío con estilo
class EmptyRecordsWidget extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onActionPressed;
  final String? actionText;

  const EmptyRecordsWidget({
    super.key,
    this.title = 'No hay registros',
    this.subtitle = '¡Agrega tu primer registro de ahorro!',
    this.icon = Icons.savings,
    this.onActionPressed,
    this.actionText,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                size: 64,
                color: Colors.grey[400],
              ),
            ),
            
            const SizedBox(height: 24),
            
            Text(
              title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
            
            const SizedBox(height: 8),
            
            Text(
              subtitle,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            
            if (onActionPressed != null && actionText != null) ...[
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: onActionPressed,
                icon: const Icon(Icons.add),
                label: Text(actionText!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}