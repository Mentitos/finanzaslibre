import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/savings_record.dart';

class RecordDialog extends StatefulWidget {
  final Function(SavingsRecord) onSave;
  final List<String> categories;
  final SavingsRecord? record;
  final String? initialCategory;

  const RecordDialog({
    super.key,
    required this.onSave,
    required this.categories,
    this.record,
    this.initialCategory,
  });

  @override
  State<RecordDialog> createState() => _RecordDialogState();
}

class _RecordDialogState extends State<RecordDialog>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _physicalController = TextEditingController();
  final _digitalController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _notesController = TextEditingController();

  RecordType _selectedType = RecordType.deposit;
  String _selectedCategory = 'General';
  bool _isLoading = false;

  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  bool get _isEditing => widget.record != null;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));

    _animationController.forward();

    _initializeFields();
  }

  void _initializeFields() {
    if (_isEditing) {
      final record = widget.record!;
      _physicalController.text = record.physicalAmount > 0
          ? record.physicalAmount.toStringAsFixed(0)
          : '';
      _digitalController.text = record.digitalAmount > 0
          ? record.digitalAmount.toStringAsFixed(0)
          : '';
      _descriptionController.text = record.description;
      _notesController.text = record.notes ?? '';
      _selectedType = record.type;
      _selectedCategory = record.category;
    } else {
      _selectedCategory = widget.initialCategory ??
          (widget.categories.isNotEmpty ? widget.categories.first : 'General');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _physicalController.dispose();
    _digitalController.dispose();
    _descriptionController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: AlertDialog(
        title: Row(
          children: [
            Icon(
              _isEditing ? Icons.edit : Icons.add,
              color: _selectedType == RecordType.deposit ? Colors.green : Colors.red,
            ),
            const SizedBox(width: 8),
            Text(_isEditing ? 'Editar Registro' : 'Nuevo Registro'),
          ],
        ),
        content: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTypeSelector(),
                const SizedBox(height: 16),
                _buildAmountInputs(),
                const SizedBox(height: 16),
                _buildCategorySelector(),
                const SizedBox(height: 16),
                _buildDescriptionInput(),
                const SizedBox(height: 16),
                _buildNotesInput(),
              ],
            ),
          ),
        ),
        actions: _buildActions(),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }

  Widget _buildTypeSelector() {
    return Card(
      color: Colors.grey[50],
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Row(
          children: [
            Expanded(
              child: _buildTypeOption(
                RecordType.deposit,
                'Depósito',
                Icons.add_circle,
                Colors.green,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildTypeOption(
                RecordType.withdrawal,
                'Retiro',
                Icons.remove_circle,
                Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeOption(
    RecordType type,
    String label,
    IconData icon,
    Color color,
  ) {
    final isSelected = _selectedType == type;
    
    return GestureDetector(
      onTap: () => setState(() => _selectedType = type),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSelected ? color : Colors.grey[300]!,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: isSelected ? color : Colors.grey[500],
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? color : Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAmountInputs() {
    return Row(
      children: [
        Expanded(
          child: _buildAmountField(
            controller: _physicalController,
            label: 'Dinero Físico',
            icon: Icons.account_balance_wallet,
            color: Colors.blue,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildAmountField(
            controller: _digitalController,
            label: 'Dinero Digital',
            icon: Icons.credit_card,
            color: Colors.purple,
          ),
        ),
      ],
    );
  }

  Widget _buildAmountField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    required Color color,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: color),
        border: const OutlineInputBorder(),
        prefixText: '\$',
        suffixIcon: controller.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear, size: 18),
                onPressed: () => setState(() => controller.clear()),
              )
            : null,
      ),
      keyboardType: TextInputType.number,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
        LengthLimitingTextInputFormatter(10),
      ],
      validator: (value) {
        final physical = double.tryParse(_physicalController.text) ?? 0;
        final digital = double.tryParse(_digitalController.text) ?? 0;
        
        if (physical == 0 && digital == 0) {
          return 'Ingrese al menos una cantidad';
        }
        return null;
      },
      onChanged: (value) => setState(() {}), // Para actualizar suffixIcon
    );
  }

  Widget _buildCategorySelector() {
    return DropdownButtonFormField<String>(
      value: _selectedCategory,
      decoration: const InputDecoration(
        labelText: 'Categoría',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.category),
      ),
      items: widget.categories.map((category) {
        return DropdownMenuItem(
          value: category,
          child: Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: _getCategoryColor(category),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(category),
            ],
          ),
        );
      }).toList(),
      onChanged: (value) => setState(() => _selectedCategory = value!),
      validator: (value) => value == null ? 'Seleccione una categoría' : null,
    );
  }

  Widget _buildDescriptionInput() {
    return TextFormField(
      controller: _descriptionController,
      decoration: const InputDecoration(
        labelText: 'Descripción',
        border: OutlineInputBorder(),
        prefixIcon: Icon(Icons.description),
        hintText: 'Ej: Ahorro mensual, gastos varios...',
      ),
      maxLines: 2,
      maxLength: 100,
      textCapitalization: TextCapitalization.sentences,
    );
  }

  Widget _buildNotesInput() {
    return TextFormField(
      controller: _notesController,
      decoration: InputDecoration(
        labelText: 'Notas adicionales (opcional)',
        border: const OutlineInputBorder(),
        prefixIcon: const Icon(Icons.note_add),
        hintText: 'Información extra...',
        helperText: 'Campo opcional para más detalles',
        suffixIcon: _notesController.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear, size: 18),
                onPressed: () => setState(() => _notesController.clear()),
              )
            : null,
      ),
      maxLines: 3,
      maxLength: 200,
      textCapitalization: TextCapitalization.sentences,
      onChanged: (value) => setState(() {}), // Para actualizar suffixIcon
    );
  }

  List<Widget> _buildActions() {
    return [
      TextButton(
        onPressed: _isLoading ? null : () => Navigator.pop(context),
        child: const Text('Cancelar'),
      ),
      FilledButton(
        onPressed: _isLoading ? null : _saveRecord,
        child: _isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : Text(_isEditing ? 'Actualizar' : 'Guardar'),
      ),
    ];
  }

  void _saveRecord() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    // Simular un pequeño delay para UX
    await Future.delayed(const Duration(milliseconds: 500));

    final physical = double.tryParse(_physicalController.text) ?? 0;
    final digital = double.tryParse(_digitalController.text) ?? 0;

    final record = SavingsRecord(
      id: _isEditing 
          ? widget.record!.id 
          : DateTime.now().millisecondsSinceEpoch.toString(),
      physicalAmount: physical,
      digitalAmount: digital,
      description: _descriptionController.text.trim(),
      createdAt: _isEditing ? widget.record!.createdAt : DateTime.now(),
      type: _selectedType,
      category: _selectedCategory,
      notes: _notesController.text.trim().isEmpty 
          ? null 
          : _notesController.text.trim(),
    );

    widget.onSave(record);
    
    if (mounted) {
      Navigator.pop(context);
      
      // Mostrar feedback
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _isEditing 
                ? 'Registro actualizado exitosamente' 
                : 'Registro creado exitosamente',
          ),
          backgroundColor: _selectedType == RecordType.deposit 
              ? Colors.green 
              : Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Color _getCategoryColor(String category) {
    // Colores predefinidos para categorías
    const colors = [
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.red,
      Colors.teal,
      Colors.indigo,
    ];
    
    final hash = category.hashCode;
    return colors[hash.abs() % colors.length];
  }
}

// Widget para selección rápida de cantidades comunes
class QuickAmountSelector extends StatelessWidget {
  final Function(double) onAmountSelected;
  final List<double> amounts;

  const QuickAmountSelector({
    super.key,
    required this.onAmountSelected,
    this.amounts = const [1000, 5000, 10000, 20000, 50000],
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: amounts.length,
        separatorBuilder: (context, index) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final amount = amounts[index];
          return _buildAmountChip(amount);
        },
      ),
    );
  }

  Widget _buildAmountChip(double amount) {
    return ActionChip(
      label: Text(
        '\$${_formatCurrency(amount)}',
        style: const TextStyle(fontSize: 12),
      ),
      onPressed: () => onAmountSelected(amount),
      backgroundColor: Colors.grey[100],
      side: BorderSide(color: Colors.grey[300]!),
    );
  }

  String _formatCurrency(double number) {
    return number.toStringAsFixed(0).replaceAllMapped(
      RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'),
      (Match m) => '${m[1]},',
    );
  }
}